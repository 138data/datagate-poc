const fs = require('fs').promises;
const path = require('path');
const authMiddleware = require('../middleware/auth');

async function handleCleanup(req, res) {
    // CORSヘッダー
    res.setHeader('Access-Control-Allow-Credentials', true);
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET,OPTIONS,PATCH,DELETE,POST,PUT');
    res.setHeader(
        'Access-Control-Allow-Headers',
        'X-CSRF-Token, X-Requested-With, Accept, Accept-Version, Content-Length, Content-MD5, Content-Type, Date, X-Api-Version, Authorization'
    );

    if (req.method === 'OPTIONS') {
        res.status(200).end();
        return;
    }

    if (req.method !== 'POST') {
        return res.status(405).json({ error: 'Method not allowed' });
    }

    try {
        console.log(`🧹 クリーンアップAPI実行: ${new Date().toLocaleString()} (ユーザー: ${req.user.username})`);
        
        const storageDir = path.join(process.cwd(), 'storage');
        let deletedCount = 0;
        const deletedFiles = [];
        
        // 設定ファイルから保持期間を取得
        let retentionHours = 24; // デフォルト値
        try {
            const settingsPath = path.join(process.cwd(), 'config', 'settings.json');
            const settingsContent = await fs.readFile(settingsPath, 'utf8');
            const settings = JSON.parse(settingsContent);
            retentionHours = settings.retentionHours || 24;
        } catch (error) {
            console.log('[クリーンアップ] デフォルトの保持期間を使用: 24時間');
        }
        
        // storageディレクトリの確認
        try {
            await fs.access(storageDir);
        } catch {
            console.log('[クリーンアップ] storageディレクトリが存在しません');
            return res.status(200).json({ deleted: 0, message: 'ファイルがありません' });
        }
        
        // ファイル一覧を取得
        const files = await fs.readdir(storageDir);
        const now = new Date();
        
        for (const file of files) {
            try {
                // メタデータファイルのみを処理
                if (!file.endsWith('.json')) {
                    continue;
                }
                
                const metadataPath = path.join(storageDir, file);
                const metadataContent = await fs.readFile(metadataPath, 'utf8');
                const metadata = JSON.parse(metadataContent);
                
                const uploadTime = new Date(metadata.uploadTime);
                const ageInHours = (now - uploadTime) / (1000 * 60 * 60);
                
                // 削除条件のチェック
                let shouldDelete = false;
                let deleteReason = '';
                
                // 1. 保存期限切れ
                if (ageInHours > retentionHours) {
                    shouldDelete = true;
                    deleteReason = `保存期限切れ (${Math.floor(ageInHours)}時間経過)`;
                }
                
                // 2. ダウンロード回数上限到達
                if (metadata.downloads >= metadata.maxDownloads) {
                    shouldDelete = true;
                    deleteReason = `ダウンロード上限到達 (${metadata.downloads}/${metadata.maxDownloads})`;
                }
                
                if (shouldDelete) {
                    const fileId = file.replace('.json', '');
                    const dataPath = path.join(storageDir, `${fileId}.data`);
                    
                    console.log(`[削除ログ] ${deleteReason}: ${metadata.originalName}`);
                    
                    // データファイルを削除
                    try {
                        await fs.unlink(dataPath);
                    } catch (error) {
                        // データファイルが既に存在しない場合は無視
                    }
                    
                    // メタデータファイルを削除
                    await fs.unlink(metadataPath);
                    
                    deletedFiles.push({
                        name: metadata.originalName,
                        reason: deleteReason
                    });
                    deletedCount++;
                }
            } catch (error) {
                console.error(`[クリーンアップエラー] ファイル処理失敗: ${file}`, error);
            }
        }
        
        // ログ記録
        const logEntry = {
            event: 'cleanup',
            user: req.user.username,
            deletedCount: deletedCount,
            deletedFiles: deletedFiles,
            timestamp: new Date().toISOString()
        };
        
        const logsDir = path.join(process.cwd(), 'logs');
        await fs.mkdir(logsDir, { recursive: true });
        
        const logFile = path.join(logsDir, `cleanup-${new Date().toISOString().split('T')[0]}.log`);
        await fs.appendFile(logFile, JSON.stringify(logEntry) + '\n');
        
        console.log(`クリーンアップ完了: ${deletedCount}個のファイルを削除`);
        
        res.status(200).json({ 
            success: true,
            deleted: deletedCount,
            deletedFiles: deletedFiles,
            message: `${deletedCount}個のファイルを削除しました`
        });
        
    } catch (error) {
        console.error('[クリーンアップエラー]:', error);
        res.status(500).json({ 
            error: 'クリーンアップ中にエラーが発生しました',
            details: error.message
        });
    }
}

// 認証ミドルウェアでラップしてエクスポート
module.exports = authMiddleware(handleCleanup);