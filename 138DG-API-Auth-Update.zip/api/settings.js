const fs = require('fs').promises;
const path = require('path');
const authMiddleware = require('../middleware/auth');

const SETTINGS_PATH = path.join(process.cwd(), 'config', 'settings.json');

// デフォルト設定
const DEFAULT_SETTINGS = {
    maxDownloads: 3,
    retentionHours: 24,
    maxFileSize: 100, // MB
    autoDelete: true
};

async function handleSettings(req, res) {
    // CORSヘッダー
    res.setHeader('Access-Control-Allow-Credentials', true);
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET,OPTIONS,PATCH,DELETE,POST,PUT');
    res.setHeader(
        'Access-Control-Allow-Headers',
        'X-CSRF-Token, X-Requested-With, Accept, Accept-Version, Content-Length, Content-MD5, Content-Type, Date, X-Api-Version, Authorization'
    );

    if (req.method === 'OPTIONS') {
        res.status(200).end();
        return;
    }

    try {
        // GET: 設定を取得
        if (req.method === 'GET') {
            console.log(`[設定取得] ユーザー: ${req.user.username}`);
            
            try {
                const data = await fs.readFile(SETTINGS_PATH, 'utf8');
                const settings = JSON.parse(data);
                res.status(200).json(settings);
            } catch (error) {
                // ファイルが存在しない場合はデフォルト設定を返す
                res.status(200).json(DEFAULT_SETTINGS);
            }
            return;
        }

        // POST: 設定を更新
        if (req.method === 'POST' || req.method === 'PUT') {
            console.log(`[設定更新] ユーザー: ${req.user.username}`);
            
            const newSettings = req.body;
            
            // バリデーション
            if (newSettings.maxDownloads && (newSettings.maxDownloads < 1 || newSettings.maxDownloads > 100)) {
                return res.status(400).json({ error: '最大ダウンロード回数は1-100の間で設定してください' });
            }
            
            if (newSettings.retentionHours && (newSettings.retentionHours < 1 || newSettings.retentionHours > 720)) {
                return res.status(400).json({ error: '保持期間は1-720時間の間で設定してください' });
            }
            
            if (newSettings.maxFileSize && (newSettings.maxFileSize < 1 || newSettings.maxFileSize > 5000)) {
                return res.status(400).json({ error: '最大ファイルサイズは1-5000MBの間で設定してください' });
            }
            
            // 既存の設定を読み込み
            let currentSettings = DEFAULT_SETTINGS;
            try {
                const data = await fs.readFile(SETTINGS_PATH, 'utf8');
                currentSettings = JSON.parse(data);
            } catch (error) {
                // ファイルがない場合はデフォルトを使用
            }
            
            // 設定をマージ
            const updatedSettings = {
                ...currentSettings,
                ...newSettings,
                updatedAt: new Date().toISOString(),
                updatedBy: req.user.username
            };
            
            // 設定を保存
            await fs.mkdir(path.dirname(SETTINGS_PATH), { recursive: true });
            await fs.writeFile(SETTINGS_PATH, JSON.stringify(updatedSettings, null, 2));
            
            // ログ記録
            const logEntry = {
                event: 'settings_update',
                user: req.user.username,
                changes: newSettings,
                timestamp: new Date().toISOString()
            };
            
            const logsDir = path.join(process.cwd(), 'logs');
            await fs.mkdir(logsDir, { recursive: true });
            
            const logFile = path.join(logsDir, `settings-${new Date().toISOString().split('T')[0]}.log`);
            await fs.appendFile(logFile, JSON.stringify(logEntry) + '\n');
            
            console.log('[設定更新] 完了:', updatedSettings);
            
            res.status(200).json({ 
                success: true, 
                message: '設定を更新しました',
                settings: updatedSettings
            });
            return;
        }

        res.status(405).json({ error: 'Method not allowed' });
        
    } catch (error) {
        console.error('[設定エラー]:', error);
        res.status(500).json({ 
            error: '設定の処理中にエラーが発生しました',
            details: error.message
        });
    }
}

// 認証ミドルウェアでラップしてエクスポート
module.exports = authMiddleware(handleSettings);