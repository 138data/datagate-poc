const fs = require('fs').promises;
const path = require('path');
const authMiddleware = require('../middleware/auth');

async function handleGetStats(req, res) {
    // CORSヘッダー
    res.setHeader('Access-Control-Allow-Credentials', true);
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET,OPTIONS,PATCH,DELETE,POST,PUT');
    res.setHeader(
        'Access-Control-Allow-Headers',
        'X-CSRF-Token, X-Requested-With, Accept, Accept-Version, Content-Length, Content-MD5, Content-Type, Date, X-Api-Version, Authorization'
    );

    if (req.method === 'OPTIONS') {
        res.status(200).end();
        return;
    }

    if (req.method !== 'GET') {
        return res.status(405).json({ error: 'Method not allowed' });
    }

    try {
        console.log(`[統計情報] 取得開始 (ユーザー: ${req.user.username})`);
        
        const storageDir = path.join(process.cwd(), 'storage');
        const logsDir = path.join(process.cwd(), 'logs');
        
        // 統計情報の初期値
        const stats = {
            totalFiles: 0,
            totalSize: 0,
            todayUploads: 0,
            todayDownloads: 0,
            activeFiles: 0,
            expiredFiles: 0
        };
        
        // storageディレクトリの確認
        try {
            await fs.access(storageDir);
        } catch {
            return res.status(200).json(stats);
        }

        // ファイル一覧を取得
        const files = await fs.readdir(storageDir);
        
        // メタデータファイル（.json）のみを処理
        const metadataFiles = files.filter(file => file.endsWith('.json'));
        
        const today = new Date().toISOString().split('T')[0];
        
        for (const metaFile of metadataFiles) {
            try {
                const metadataPath = path.join(storageDir, metaFile);
                const metadataContent = await fs.readFile(metadataPath, 'utf8');
                const metadata = JSON.parse(metadataContent);
                
                // ファイルIDを取得
                const fileId = metaFile.replace('.json', '');
                
                // データファイルのサイズを取得
                try {
                    const dataPath = path.join(storageDir, `${fileId}.data`);
                    const fileStats = await fs.stat(dataPath);
                    stats.totalSize += fileStats.size;
                } catch (error) {
                    // データファイルがない場合はメタデータから
                    stats.totalSize += metadata.size || 0;
                }
                
                stats.totalFiles++;
                
                // 今日のアップロードをカウント
                if (metadata.uploadTime && metadata.uploadTime.startsWith(today)) {
                    stats.todayUploads++;
                }
                
                // 期限切れチェック
                const uploadTime = new Date(metadata.uploadTime);
                const expiryTime = new Date(uploadTime.getTime() + metadata.retentionHours * 60 * 60 * 1000);
                
                if (expiryTime < new Date()) {
                    stats.expiredFiles++;
                } else {
                    stats.activeFiles++;
                }
                
            } catch (error) {
                console.error(`[統計エラー] メタデータ読み込みエラー: ${metaFile}`, error);
            }
        }
        
        // ログから今日のダウンロード数を取得
        try {
            const todayLogFile = path.join(logsDir, `downloads-${today}.log`);
            const logContent = await fs.readFile(todayLogFile, 'utf8');
            const logLines = logContent.split('\n').filter(line => line.trim());
            stats.todayDownloads = logLines.length;
        } catch (error) {
            // ログファイルがない場合は0
            stats.todayDownloads = 0;
        }
        
        console.log(`[統計情報] 総ファイル: ${stats.totalFiles}, 総容量: ${stats.totalSize} bytes`);
        
        res.status(200).json(stats);
        
    } catch (error) {
        console.error('[統計情報エラー]:', error);
        res.status(500).json({ 
            error: '統計情報の取得中にエラーが発生しました',
            details: error.message
        });
    }
}

// 認証ミドルウェアでラップしてエクスポート
module.exports = authMiddleware(handleGetStats);