const fs = require('fs').promises;
const path = require('path');
const authMiddleware = require('../middleware/auth');

async function handleGetFiles(req, res) {
    // CORSヘッダー
    res.setHeader('Access-Control-Allow-Credentials', true);
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET,OPTIONS,PATCH,DELETE,POST,PUT');
    res.setHeader(
        'Access-Control-Allow-Headers',
        'X-CSRF-Token, X-Requested-With, Accept, Accept-Version, Content-Length, Content-MD5, Content-Type, Date, X-Api-Version, Authorization'
    );

    if (req.method === 'OPTIONS') {
        res.status(200).end();
        return;
    }

    if (req.method !== 'GET') {
        return res.status(405).json({ error: 'Method not allowed' });
    }

    try {
        console.log(`[ファイル一覧] 取得開始 (ユーザー: ${req.user.username})`);
        
        const storageDir = path.join(process.cwd(), 'storage');
        
        // storageディレクトリの確認
        try {
            await fs.access(storageDir);
        } catch {
            await fs.mkdir(storageDir, { recursive: true });
            return res.status(200).json([]);
        }

        // ファイル一覧を取得
        const files = await fs.readdir(storageDir);
        
        // メタデータファイル（.json）のみをフィルタリング
        const metadataFiles = files.filter(file => file.endsWith('.json'));
        
        const fileList = [];
        
        for (const metaFile of metadataFiles) {
            try {
                const metadataPath = path.join(storageDir, metaFile);
                const metadataContent = await fs.readFile(metadataPath, 'utf8');
                const metadata = JSON.parse(metadataContent);
                
                // ファイルIDを取得（.jsonを除く）
                const fileId = metaFile.replace('.json', '');
                
                // データファイルのサイズを取得
                let fileSize = 0;
                try {
                    const dataPath = path.join(storageDir, `${fileId}.data`);
                    const stats = await fs.stat(dataPath);
                    fileSize = stats.size;
                } catch (error) {
                    console.log(`[警告] データファイルが見つかりません: ${fileId}`);
                    // データファイルがない場合はメタデータから取得
                    fileSize = metadata.size || 0;
                }
                
                // ダウンロード期限の計算
                const uploadTime = new Date(metadata.uploadTime);
                const expiryTime = new Date(uploadTime.getTime() + metadata.retentionHours * 60 * 60 * 1000);
                const isExpired = expiryTime < new Date();
                
                fileList.push({
                    id: fileId,
                    name: metadata.originalName,
                    size: fileSize,
                    uploadTime: metadata.uploadTime,
                    expiryTime: expiryTime.toISOString(),
                    isExpired: isExpired,
                    downloads: metadata.downloads || 0,
                    maxDownloads: metadata.maxDownloads,
                    senderEmail: metadata.senderEmail,
                    recipientEmail: metadata.recipientEmail,
                    remainingDownloads: metadata.maxDownloads - (metadata.downloads || 0)
                });
            } catch (error) {
                console.error(`[エラー] メタデータ読み込みエラー: ${metaFile}`, error);
            }
        }
        
        // アップロード時間で降順ソート（新しいものを上に）
        fileList.sort((a, b) => new Date(b.uploadTime) - new Date(a.uploadTime));
        
        console.log(`[ファイル一覧] ${fileList.length}個のファイルを返却`);
        
        res.status(200).json(fileList);
        
    } catch (error) {
        console.error('[ファイル一覧エラー]:', error);
        res.status(500).json({ 
            error: 'ファイル一覧の取得中にエラーが発生しました',
            details: error.message
        });
    }
}

// 認証ミドルウェアでラップしてエクスポート
module.exports = authMiddleware(handleGetFiles);