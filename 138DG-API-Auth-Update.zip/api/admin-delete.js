const fs = require('fs').promises;
const path = require('path');
const authMiddleware = require('../middleware/auth');

// 認証付きハンドラー
async function handleAdminDelete(req, res) {
    // CORSヘッダー（authMiddlewareで設定済みだが念のため）
    res.setHeader('Access-Control-Allow-Credentials', true);
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET,OPTIONS,PATCH,DELETE,POST,PUT');
    res.setHeader(
        'Access-Control-Allow-Headers',
        'X-CSRF-Token, X-Requested-With, Accept, Accept-Version, Content-Length, Content-MD5, Content-Type, Date, X-Api-Version, Authorization'
    );

    if (req.method === 'OPTIONS') {
        res.status(200).end();
        return;
    }

    if (req.method !== 'POST' && req.method !== 'DELETE') {
        return res.status(405).json({ error: 'Method not allowed' });
    }

    try {
        const { fileId } = req.body;
        
        if (!fileId) {
            return res.status(400).json({ error: 'File ID is required' });
        }

        console.log(`[管理者削除] ユーザー: ${req.user.username}, ファイルID: ${fileId}`);

        const storageDir = path.join(process.cwd(), 'storage');
        
        // メタデータファイルのパス
        const metadataPath = path.join(storageDir, `${fileId}.json`);
        
        // メタデータの確認
        let metadata;
        try {
            const metadataContent = await fs.readFile(metadataPath, 'utf8');
            metadata = JSON.parse(metadataContent);
        } catch (error) {
            console.error(`[削除エラー] メタデータが見つかりません: ${fileId}`);
            return res.status(404).json({ error: 'ファイルが見つかりません' });
        }

        // 実ファイルのパス
        const filePath = path.join(storageDir, `${fileId}.data`);
        
        // ファイルとメタデータを削除
        const deletions = [];
        
        // 実ファイル削除
        try {
            await fs.access(filePath);
            deletions.push(fs.unlink(filePath));
            console.log(`[削除] データファイル: ${filePath}`);
        } catch (error) {
            console.log(`[削除スキップ] データファイルが存在しません: ${filePath}`);
        }
        
        // メタデータ削除
        try {
            await fs.access(metadataPath);
            deletions.push(fs.unlink(metadataPath));
            console.log(`[削除] メタデータ: ${metadataPath}`);
        } catch (error) {
            console.log(`[削除スキップ] メタデータが存在しません: ${metadataPath}`);
        }
        
        // 削除実行
        if (deletions.length > 0) {
            await Promise.all(deletions);
        }

        // ログ記録
        const logEntry = {
            event: 'admin_delete',
            user: req.user.username,
            fileId: fileId,
            fileName: metadata.originalName,
            timestamp: new Date().toISOString()
        };
        
        const logsDir = path.join(process.cwd(), 'logs');
        await fs.mkdir(logsDir, { recursive: true });
        
        const logFile = path.join(logsDir, `admin-actions-${new Date().toISOString().split('T')[0]}.log`);
        await fs.appendFile(logFile, JSON.stringify(logEntry) + '\n');

        console.log(`[削除完了] ファイル: ${metadata.originalName} (${fileId})`);
        
        res.status(200).json({ 
            success: true, 
            message: 'ファイルを削除しました',
            deletedFile: metadata.originalName
        });

    } catch (error) {
        console.error('[管理者削除エラー]:', error);
        res.status(500).json({ 
            error: 'ファイルの削除中にエラーが発生しました',
            details: error.message 
        });
    }
}

// 認証ミドルウェアでラップしてエクスポート
module.exports = authMiddleware(handleAdminDelete);